import { redirect } from "next/navigation";
import { canManageLeague } from "@/lib/auth";
import { currentPlayer, loadInvites, loadMetaEvents, loadPlayerEmails, loadSnapshot } from "@/lib/data";
import { availableSeasons, getSeason } from "@/lib/cp";
import { asEloScope, ELO_SCOPES, isPlayed, sideOf } from "@/lib/stats";
import { PageHead, SectionTitle } from "@/components/ui";
import { ArchetypeSync } from "@/components/ArchetypeSync";
import { MetaImport } from "@/components/MetaImport";
import { EVENTOS_EUROPA_2027 } from "@/data/eventos-europa";
import { hasPokemonTcgKey } from "@/lib/sources/pokemontcg";
import { InviteManager } from "@/components/InviteManager";
import { PlayerAdmin } from "@/components/PlayerAdmin";
import { PasswordForm } from "@/components/PasswordForm";
import { isOwner } from "@/lib/auth";
import { clearEloReset, purgePlayer, resetElo, resetLadderSeason, resetLeague, saveSettings, syncLimitlessIrl, wipeSeason } from "@/actions";
import { Icon } from "@/components/icons";

export const metadata = { title: "Ajustes" };

/**
 * Sincronizar el catálogo son varias decenas de llamadas encadenadas a
 * Limitless y a PokéAPI. Con el límite por defecto de Vercel se quedaba a
 * medias; 60 segundos es lo máximo del plan gratuito y sobra de largo.
 */
export const maxDuration = 60;

export default async function SettingsPage() {
  const [snap, me] = await Promise.all([loadSnapshot(), currentPlayer()]);
  if (!me) redirect("/entrar");
  const manager = canManageLeague(me.role);
  const owner = isOwner(me.role);
  const invites = manager ? await loadInvites() : [];
  // Solo el booleano. La clave en sí no sale nunca de la variable de entorno.
  const tcgKey = hasPokemonTcgKey();
  const eloScope = asEloScope(snap.config.eloScope);
  const emails: Record<string, string> = manager ? await loadPlayerEmails() : {};
  // Lo importado de los Regionales va aparte del snapshot: crece más deprisa
  // que el resto y solo hace falta aquí y en Top Decks.
  const metaEventos = manager ? await loadMetaEvents() : [];

  const played = snap.matches.filter(isPlayed);
  const counts = Object.fromEntries(
    snap.players.map((p) => [p.id, played.filter((m) => sideOf(m, p.id)).length]),
  );

  // Solo se ofrecen temporadas que de verdad tienen torneos: un desplegable
  // con años vacíos invita a borrar la equivocada.
  const seasonsWithTournaments = [...new Set(
    snap.tournaments.map((t) => t.season).filter((x): x is number => x != null),
  )].sort((a, b) => b - a);
  const tournamentsBySeason = Object.fromEntries(
    seasonsWithTournaments.map((y) => [y, snap.tournaments.filter((t) => t.season === y).length]),
  );

  return (
    <>
      <PageHead
        title="Ajustes"
        sub={manager
          ? "Puntuación, invitaciones y jugadores. Los puntos y el Elo se recalculan desde el historial, así que cambiar la puntuación reordena el ranking al momento."
          : "Tu cuenta. Para cambiar la configuración de la liga habla con el organizador."}
      />

      {manager && (
        <>
          <SectionTitle aside="cualquiera con el enlace puede darse de alta">Invitaciones</SectionTitle>
          <InviteManager invites={invites} />

          <SectionTitle>La liga</SectionTitle>
          <form action={saveSettings} className="card mb-6 flex flex-col gap-4 p-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex flex-col gap-1.5">
                <label className="label" htmlFor="s-name">Nombre</label>
                <input className="input" id="s-name" name="name" defaultValue={snap.config.name} />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="label" htmlFor="s-season">Temporada</label>
                <input className="input" id="s-season" name="season" defaultValue={snap.config.season} />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {([["ptsWin", "Pts victoria"], ["ptsTie", "Pts empate"], ["ptsLoss", "Pts derrota"]] as const).map(([n, l]) => (
                <div className="flex flex-col gap-1.5" key={n}>
                  <label className="label" htmlFor={`s-${n}`}>{l}</label>
                  <input className="input" id={`s-${n}`} name={n} type="number" inputMode="numeric"
                    defaultValue={snap.config[n]} />
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <label className="label" htmlFor="s-eloStart">Elo inicial</label>
                <input className="input" id="s-eloStart" name="eloStart" type="number" inputMode="numeric" defaultValue={snap.config.eloStart} />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="label" htmlFor="s-eloK">Factor K</label>
                <input className="input" id="s-eloK" name="eloK" type="number" inputMode="numeric" defaultValue={snap.config.eloK} />
                <p className="text-xs text-muted">Cuánto mueve una partida el Elo. 24 va bien para grupos pequeños.</p>
              </div>
            </div>

            {/* Qué partidas mueven el Elo. Cambiarlo no migra nada: el Elo se
                recalcula entero desde las partidas en cada carga, así que el
                ranking sale distinto en la siguiente pantalla y se puede
                volver atrás cuando se quiera. */}
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex flex-col gap-1.5">
                <label className="label" htmlFor="s-eloScope">Qué partidas mueven el Elo</label>
                <select className="input" id="s-eloScope" name="eloScope" defaultValue={eloScope}>
                  {Object.entries(ELO_SCOPES).map(([v, d]) => (
                    <option key={v} value={v}>{d.label}</option>
                  ))}
                </select>
                <p className="text-xs text-muted">{ELO_SCOPES[eloScope].hint}</p>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="label" htmlFor="s-eloSince">Contar el Elo desde</label>
                <input
                  className="input" id="s-eloSince" name="eloSince" type="date"
                  defaultValue={snap.config.eloSince ?? ""}
                />
                <p className="text-xs text-muted">
                  Vacío = desde el principio. Es la forma de reiniciar el Elo sin borrar
                  ninguna partida.
                </p>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex flex-col gap-1.5">
                <label className="label" htmlFor="s-cpSeason">Temporada de Championship Points</label>
                <select className="input" id="s-cpSeason" name="cpSeason" defaultValue={String(snap.config.cpSeason)}>
                  {availableSeasons().map((y) => (
                    <option key={y} value={y}>
                      {y}{getSeason(y).confirmed ? "" : " (cifras provisionales)"}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="label" htmlFor="s-zone">Zona de clasificación</label>
                <select className="input" id="s-zone" name="ratingZone" defaultValue={snap.config.ratingZone}>
                  <option value="europe">Europa</option>
                  <option value="us-canada">EE. UU. y Canadá</option>
                  <option value="latam">Latinoamérica</option>
                  <option value="oceania">Oceanía</option>
                  <option value="mesa">Oriente Medio y Sudáfrica</option>
                </select>
              </div>
            </div>

            <label className="inline-flex items-center gap-2 text-sm">
              <input type="checkbox" name="registrationOpen" className="size-4" defaultChecked={snap.config.registrationOpen} />
              Permitir altas nuevas con enlace de invitación
            </label>

            <button className="btn btn-brand w-full sm:w-auto" type="submit">Guardar ajustes</button>
          </form>

          {/* --- reiniciar el Elo ---
              Va fuera del formulario de ajustes y no dentro: son acciones, no
              campos, y meter un botón que cambia el ranking entre dos inputs
              es pedir que alguien lo pulse sin querer. */}
          <div className="card mb-6 p-4">
            <p className="label mb-2">Reiniciar el Elo</p>
            <p className="mb-3 text-sm text-muted">
              {snap.config.eloSince
                ? <>Ahora mismo el Elo solo cuenta las partidas desde el{" "}
                    <b className="font-mono">{snap.config.eloSince}</b>. Todo lo anterior sigue
                    guardado y aparece en el resto de la app; simplemente no mueve el Elo.</>
                : <>El Elo cuenta todas las partidas desde el principio. Reiniciarlo pone a
                    todo el mundo en {snap.config.eloStart} y empieza a contar desde hoy.</>}
            </p>
            <div className="flex flex-wrap gap-2">
              <form action={resetElo}>
                <button className="btn" type="submit">
                  <Icon name="refresh" className="size-4" /> Empezar de cero hoy
                </button>
              </form>
              {snap.config.eloSince && (
                <form action={clearEloReset}>
                  <button className="btn btn-ghost" type="submit">
                    Volver a contar desde el principio
                  </button>
                </form>
              )}
            </div>
            <p className="mt-2 text-[11px] text-muted">
              No se borra ninguna partida. El Elo no está guardado en la base: se calcula desde
              las partidas cada vez que se pinta el ranking, así que esto es del todo
              reversible.
            </p>
          </div>

          {/* --- v0.18: reset global para el cambio de temporada --- */}
          <details className="card mb-6 border-loss/40">
            <summary className="tap cursor-pointer justify-between px-4 text-sm font-semibold">
              <span className="flex items-center gap-2">
                <Icon name="refresh" className="size-4 text-loss" /> Nueva temporada: reset de todos
              </span>
              <span className="text-[11px] font-normal text-muted">organizador</span>
            </summary>
            <form action={resetLadderSeason} className="flex flex-col gap-3 border-t border-line-soft p-4">
              <p className="text-sm text-ink-2">
                Quita el rango del ladder a <b>todos</b> los jugadores ({snap.players.filter((p) => p.ladderElo != null).length}{" "}
                con rango ahora mismo) y empieza la temporada hoy. El historial no se borra: la
                gráfica del líder empezará a contar desde aquí.
                {snap.config.ladderSince && (
                  <> Última temporada empezada el <b className="font-mono">{snap.config.ladderSince.toISOString().slice(0, 10)}</b>.</>
                )}
              </p>
              <label className="inline-flex items-center gap-2 text-sm">
                <input type="checkbox" name="elo" value="1" className="size-4" defaultChecked />
                Reiniciar también el Elo de la liga (contar desde hoy; reversible)
              </label>
              <label className="inline-flex items-center gap-2 text-sm">
                <input type="checkbox" name="puestos" value="1" className="size-4" />
                Borrar también los puestos de España y Europa
              </label>
              <label className="label" htmlFor="reset-confirm">Escribe «nueva temporada» para confirmar</label>
              <input className="input" id="reset-confirm" name="confirm" required autoComplete="off" placeholder="nueva temporada" />
              <button className="btn btn-danger w-full sm:w-auto" type="submit">Empezar temporada nueva</button>
            </form>
          </details>

          <SectionTitle aside="desde Limitless">Datos del metagame</SectionTitle>
          <ArchetypeSync total={snap.archetypes.length} />

          {/* El metagame presencial. Va justo después del catálogo a
              propósito: el importador casa los mazos contra él, así que el
              orden en el que están los dos botones es el orden en el que
              conviene pulsarlos. */}
          {/* v0.14 — Regionales y City Leagues sin pegar nada. Solo mazos: ni
              los parsers leen nombres ni la tabla tiene dónde guardarlos. */}
          <SectionTitle aside="limitlesstcg.com">Regionales y City Leagues automáticos</SectionTitle>
          <div className="card mb-3 p-4 text-sm">
            <p className="text-ink-2">
              Trae de <b>Limitless TCG</b> los Regionales de la temporada y las últimas City Leagues
              de Japón que aún no estén: el recuento de mazos del Día 2 y el top cut, puesto a
              puesto. <b>Sin ningún nombre de jugador.</b> Lo que ya está no se vuelve a pedir.
            </p>
            <p className="mt-1 text-xs text-muted">
              Hasta 6 Regionales y 15 City Leagues por pulsación. Los torneos online ya llegan
              solos por la API oficial. Si Limitless pidiera que no, se apaga y se vuelve a pegar
              a mano aquí debajo.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {[["todo", "Traer todo"], ["regionales", "Solo Regionales"], ["city", "Solo City Leagues"]].map(([v, l]) => (
                <form key={v} action={syncLimitlessIrl}>
                  <input type="hidden" name="que" value={v} />
                  <button className={`btn btn-sm ${v === "todo" ? "btn-brand" : ""}`} type="submit">{l}</button>
                </form>
              ))}
            </div>
          </div>

          <SectionTitle aside="pegando la clasificación">Metagame presencial</SectionTitle>
          <MetaImport eventos={EVENTOS_EUROPA_2027} importados={metaEventos} />

          {/* Saber en qué estado están las fuentes de fuera evita la pregunta
              de «¿por qué no me sale el metagame online?» a la tercera vez.
              No se enseña ninguna clave, solo si la hay. */}
          <div className="card mt-3 p-4 text-sm">
            <p className="label mb-2">Fuentes externas</p>
            <ul className="flex flex-col gap-2">
              <li className="flex items-start gap-2">
                <span className="chip chip-global mt-0.5 flex-none">Limitless</span>
                <span className="min-w-0 text-ink-2">
                  Torneos y clasificaciones. Funciona <b>sin clave</b>: de ahí salen el catálogo
                  de arquetipos y el metagame online de Estadísticas.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className={`chip mt-0.5 flex-none ${tcgKey ? "chip-win" : ""}`}>pokemontcg.io</span>
                <span className="min-w-0 text-ink-2">
                  Datos de carta para el buscador del editor de mazos.{" "}
                  {tcgKey
                    ? "Hay clave configurada, así que el límite de peticiones es alto."
                    : "Sin clave: 1.000 peticiones al día y 30 por minuto, de sobra para la liga."}{" "}
                  <b>Esta API está deprecada</b> y deja de funcionar el 1 de marzo de 2027; ese
                  día se cambia por TCGdex y no se nota en ninguna pantalla.
                </span>
              </li>
            </ul>
          </div>

          <SectionTitle aside={`${snap.players.length} en total`}>Jugadores</SectionTitle>
          <PlayerAdmin
            players={snap.players} counts={counts} emails={emails}
            meId={me.id} meRole={me.role}
          />
        </>
      )}

      <SectionTitle>Tu cuenta</SectionTitle>
      <PasswordForm />

      {/* ---------------------------------------------------------------
          Zona de riesgo.

          Todo esto es solo del propietario y todo pide escribir a mano lo que
          se va a borrar. Es el patrón de GitHub al borrar un repositorio, y
          está por un motivo concreto: nada de esto tiene deshacer, y un botón
          sin fricción se pulsa sin leer.

          Va al final de la página y detrás de un `details` por lo mismo: no
          es algo con lo que uno se tropiece buscando otra cosa.
          --------------------------------------------------------------- */}
      {owner && (
        <>
          <SectionTitle aside="solo el propietario">Zona de riesgo</SectionTitle>
          <div className="flex flex-col gap-3">

            {seasonsWithTournaments.length > 0 && (
              <details className="card border-loss/40">
                <summary className="tap cursor-pointer justify-start px-4 text-sm font-semibold text-loss">
                  Vaciar una temporada
                </summary>
                <form action={wipeSeason} className="flex flex-col gap-3 border-t border-line-soft p-4">
                  <p className="text-sm text-ink-2">
                    Borra los torneos de esa temporada, los resultados de todos y las rondas
                    apuntadas. No toca jugadores, mazos, arquetipos ni la liga interna.
                  </p>
                  <div className="flex flex-col gap-1.5">
                    <label className="label" htmlFor="wipeSeason">Temporada</label>
                    <select className="input" id="wipeSeason" name="season" defaultValue={seasonsWithTournaments[0]}>
                      {seasonsWithTournaments.map((y) => (
                        <option key={y} value={y}>
                          {y} — {tournamentsBySeason[y]} torneo(s)
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="label" htmlFor="wipeConfirm">
                      Escribe «borrar temporada {seasonsWithTournaments[0]}»
                    </label>
                    <input
                      className="input font-mono text-sm" id="wipeConfirm" name="confirm" required
                      autoComplete="off" placeholder={`borrar temporada ${seasonsWithTournaments[0]}`}
                    />
                    <p className="text-xs text-muted">
                      Si cambias la temporada de arriba, la frase también cambia: es
                      «borrar temporada» y el año que hayas elegido.
                    </p>
                  </div>
                  <button className="btn btn-danger" type="submit">Vaciar la temporada</button>
                </form>
              </details>
            )}

            <details className="card border-loss/40">
              <summary className="tap cursor-pointer justify-start px-4 text-sm font-semibold text-loss">
                Borrar todo el historial
              </summary>
              <form action={resetLeague} className="flex flex-col gap-3 border-t border-line-soft p-4">
                <p className="text-sm text-ink-2">
                  Empezar de cero manteniendo a la gente. Se van las {played.length} partidas,
                  las competiciones, los {snap.tournaments.length} torneos, el calendario y el
                  ladder. Se quedan los jugadores con sus cuentas, sus mazos y los arquetipos.
                </p>
                <div className="flex flex-col gap-1.5">
                  <label className="label" htmlFor="resetConfirm">Escribe «borrar todo el historial»</label>
                  <input
                    className="input font-mono text-sm" id="resetConfirm" name="confirm" required
                    autoComplete="off" placeholder="borrar todo el historial"
                  />
                </div>
                <button className="btn btn-danger" type="submit">Borrar el historial</button>
              </form>
            </details>

            <details className="card border-loss/40">
              <summary className="tap cursor-pointer justify-start px-4 text-sm font-semibold text-loss">
                Borrar una persona del todo
              </summary>
              <form action={purgePlayer} className="flex flex-col gap-3 border-t border-line-soft p-4">
                <p className="text-sm text-ink-2">
                  Arriba, en «Jugadores», lo normal es <b>desactivar</b>: la persona deja de
                  aparecer pero su historial sigue ahí y el ranking cuadra. Esto es lo otro —no
                  queda rastro—, y es para cuentas de prueba o altas duplicadas.
                </p>
                <div className="flex flex-col gap-1.5">
                  <label className="label" htmlFor="purgeId">Quién</label>
                  <select className="input" id="purgeId" name="id" required defaultValue="">
                    <option value="" disabled>— elegir —</option>
                    {snap.players.filter((p) => p.id !== me.id).map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} — {counts[p.id] ?? 0} partida(s)
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="label" htmlFor="purgeConfirm">Escribe su nombre exacto</label>
                  <input
                    className="input" id="purgeConfirm" name="confirm" required
                    autoComplete="off" placeholder="Nombre tal como aparece arriba"
                  />
                </div>
                <button className="btn btn-danger" type="submit">Borrar a esa persona y todo lo suyo</button>
              </form>
            </details>
          </div>
        </>
      )}

      <section className="card mt-6 p-4">
        <h2 className="mb-2 text-lg font-bold">Cómo se calcula todo</h2>
        <div className="flex flex-col gap-2 text-sm text-ink-2">
          <p><b>Puntos.</b> Cuenta la serie, no los juegos: ganar 2–0 y 2–1 valen lo mismo.</p>
          <p><b>%V.</b> Victorias más medio empate, entre partidas jugadas.</p>
          <p><b>Resistencia.</b> Media del % de victorias de tus rivales, con suelo del 25% por rival, como en el reglamento de Play! Pokémon.</p>
          <p><b>Elo.</b> Recalculado en orden cronológico sobre todas las partidas <i>internas</i> de la liga. Las partidas contra gente de fuera no puntúan, porque no habría contra quién compensar.</p>
          <p><b>Championship Points.</b> Se calculan con la tabla de la temporada y descartando lo que se sale del Best Finish Limit. Los límites de esta liga son de casa: <b>4 mejores Challenges, 4 mejores Cups y 5 mejores Regionales</b>. Las tablas están en <code className="rounded bg-surface-2 px-1 font-mono text-xs">src/lib/cp.ts</code>.</p>
          <p><b>Rango del ladder.</b> Ese número lo pone cada uno en su perfil y no sale de ningún cálculo. Es aparte del Elo justamente para que se vea que son dos cosas distintas.</p>
          <p><b>Papeles.</b> <i>Jugador</i> gestiona lo suyo: su perfil, sus mazos, sus partidas, sus torneos y su rango. <i>Admin</i> además crea y borra competiciones y torneos, edita las partidas de cualquiera y genera invitaciones. <i>Propietario</i> es el único que reparte papeles, desactiva gente y usa la zona de riesgo.</p>
        </div>
      </section>
    </>
  );
}
